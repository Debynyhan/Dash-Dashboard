#####################################################
#
#
# CS-340 Project 1
# Animal Shelter Management System
# Debynyhan Banks
# Southern North Hampshire University
# Professor Paruchuri
# April 2, 2023 
#
# About the Program:
# Python module that enables CRUD functionality
#
#
####################################################



from pymongo import MongoClient
from bson.objectid import ObjectId
import json

class AnimalShelter(object):
    """CRUD operation for Animal collection in MongoDB"""
    
    def __init__(self, username, password):
        #Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.      
        self.client = MongoClient('mongodb://%s:%s@localhost:48356/AAC'%(username, password))
        self.database = self.client['AAC']
        print("Connection was successful")
        
        
# Complete this create method to implement C in CRUD.
    
    def create(self, data):
        # Check that query is not None
        if data is not None:
            try:
                # Insert the document into the database 
                result = self.database.animals.insert_one(data)
                
                # Return True if the insertion was successful, False otherwise
                return True if result.acknowledged else False
            except Exception as e:
                
                # If an error occured during insertion, print the error and return False
                print("Error inserting document:", e)
                return False 
        else:
            # If data parameter is None, raise a ValueError
            raise ValueError("Nothing to save, because data parameters is empty")
            
#Create method to implement the R in CRUD.      

    def read(self, query):
        
        # Check that query is not None
        if query is not None: 
            try:
                # Find documents in the collection that match the query
                result = self.database.animals.find(query, {"_id": False})
                
                #Count the number of documents that match the query
                count = self.database.animals.count_documents(query)
                
                if count == 0:
                    
                    # If no documents match, return False and an error message
                    return False, "No matching documents found"
                
                else:
                    # If one or more documents match, return True and the documents
                    return result
             
            # If exception is raised, return False and string error message
            except Exception as e:
                return False, str(e)
        else:
            
            # If data the parameter is None, raise a ValueError
            raise ValueError("Query parameter is empty")


                    
            

#Create method to implement the U in CRUD.
    
    def update(self, query, update_data):
        
        #Check if query or update_data parameters are empty, raise ValueError if any is none
        if query is None or update_data is None:
            
            raise ValueError("Query and/or update_data parameters are empty")
            
        try:
            # Update all matching documents in the collection with the given update_data
            result = self.database.animals.update_many(query, update_data)
            
            # If no documents are found, return False and a error message with empty json_output
            if result.matched_count == 0:
                return False, "No matching documents found", []
            
            # If no documents are updated, return True and a error message with empty json_output 
            if result.modified_count == 0:
                return True, "No documents updated", []
            
            # Find all updated documents with given query and convert them to json
            updated_documents = self.database.animals.find(query)
            
            json_output = [json.dumps(document, indent=2, default=str) for document in updated_documents]
            
            # Return True and a message with the number of documents updated and json
            return True, f"{result.modified_count} documents(s) updated", json_output
        
        # Catch any PyMongo errors and return False, an error message and empty json
        except PyMongoError as e:
            
            return False, str(e), []
        

            
#Create method to implement the D in CRUD
        
        
    def delete(self, query):
        
        # Check if query parameter is not None
        if query is not None:
            
            try:
                # Find the docs to be deleted and store them in a list
                deleted_documents = list(self.database.animals.find(query))
                
                # Delete the documets that match the query
                result = self.database.animals.delete_many(query)
                
                # Check to see if any docs was deleted
                if result.deleted_count == 0:
                    return False, "No matching documents found", []
                
                else: 
                    # If docs were deleted, create a json output for each deleted doc
                    json_output = [json.dumps(document, indent=2, default=str) for document in deleted_documents]
                    
                    # Return True with a message indicating the number of deleted docs and the json output
                    return True, f"{result.deleted_count} documents(s) deleted", json_output
            
            except PyMongoError as e:
                # If an error, return False with error message and a empty list for json_output
                return False, str(e), []
        else:
            # If query parameters is None, raise ValueError with a message
            raise ValueError("Query parameter is empty")
                